package net.wojdat.damian.screengler;

import android.support.annotation.DrawableRes;

public enum Timeout {

    UNKNOWN(-2, R.drawable.ic_stat_time_none),
    NEVER(-1, R.drawable.ic_stat_time_inf),
    FIFTEEN_SEC(15_000, R.drawable.ic_stat_time_15s),
    THIRTY_SEC(30_000, R.drawable.ic_stat_time_30s),
    ONE_MIN(60_000, R.drawable.ic_stat_time_1),
    TWO_MIN(120_000, R.drawable.ic_stat_time_2),
    FIVE_MIN(300_000, R.drawable.ic_stat_time_5),
    TEN_MIN(600_000, R.drawable.ic_stat_time_10),
    FIFTEEN_MIN(900_000, R.drawable.ic_stat_time_15),
    THIRTEEN_MIN(1_800_000, R.drawable.ic_stat_time_30);

    Timeout(int timeMs, @DrawableRes int resId) {
        this.timeMs = timeMs;
        this.resId = resId;
    }

    private int timeMs;

    @DrawableRes
    private int resId;

    public int getTimeMs() {
        return timeMs;
    }

    @DrawableRes
    public int getResId() {
        return resId;
    }
}
