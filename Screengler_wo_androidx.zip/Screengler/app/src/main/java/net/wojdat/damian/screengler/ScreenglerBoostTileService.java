package net.wojdat.damian.screengler;

public class ScreenglerBoostTileService extends ScreenglerTileService {
}
